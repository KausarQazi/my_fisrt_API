
public class HumariApi {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		Math math=new Math();
		
		int a=math.Add(9, 4);
		int s=math.Sub(13,4);
		int m=math.Mul(6,4);
		int d=math.Div(16,4);
		
		System.out.println("Addition is: "+a);
		System.out.println("Subtrction is: "+s);
		System.out.println("Multiplication is: "+m);
		System.out.println("Division is: "+d);
		
		
	}
	
}
