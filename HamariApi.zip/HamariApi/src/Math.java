
/**
 * 
 * This program is a simple example of calculator API that can
 * be used by any other user. you just need to import it to use my API.
 *   
 * @author Kausar Qazi
 * @version 1.1
 * @param Add - the addition of two numbers x and y
 * @param Sub - the subtraction of two numbers x and y
 * @param Mul - the Multiplication of two numbers x and y
 * @param Div - the division of two numbers x and y
 * 
 */

public class Math {

	/**
	 * 
	 * @param x specifies the integer number 1
	 * @param y specifies the integer number 2
	 * @return - returns the desired output
	 */
	public int Add(int x, int y) {
		// TODO Auto-generated method stub
		int z=x+y;
		return z;
	}
		public int Sub(int x, int y){
			int z=x-y;
			return z;
		}
		public  int Mul(int x, int y){
			int z=x*y;
			return z;
		}
		public  int Div(int x, int y){
			int z=x/y;
			return z;
		}
}
